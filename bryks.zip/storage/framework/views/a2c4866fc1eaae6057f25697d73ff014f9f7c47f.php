<h1>Forget Password Email</h1>

You can reset password from bellow link:
<a href="<?php echo e(route('reset.password.get', $token)); ?>">Reset Password</a>
<?php /**PATH C:\xampp\htdocs\bryks\resources\views/mail/forgetPassword.blade.php ENDPATH**/ ?>