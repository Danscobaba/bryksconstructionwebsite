<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&family=Russo+One&family=Tiro+Gurmukhi&family=Unna:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" referrerpolicy="no-referrer" />
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="<?php echo e(asset('css/flowbite.min.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    
</head>
<body>
<style>
    *{
        margin: 0px;
        padding: 0px;
        box-sizing: border-box;
    }
    .container-fluid{
        background: whitesmoke;
        border: 1px solid;
        height: 100vh;
        font-size: 18px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>

<div class="container-fluid">
    <?php echo $__env->yieldContent('content'); ?>
</div>





<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js" referrerpolicy="no-referrer"></script>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\bryks\resources\views/auth/min.blade.php ENDPATH**/ ?>