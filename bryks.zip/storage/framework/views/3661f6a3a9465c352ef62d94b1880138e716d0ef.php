<?php $__env->startSection('title', 'forgot password'); ?>
<?php $__env->startSection('content'); ?>

  <div class="container d-flex justify-center">

              <div class="card" style="width: 600px">
                <a href="<?php echo e(url('admin-login')); ?>" class="btn btn-outline-primary">back to login</a>
                  <div class="card-header text-center">Reset Password</div>
                  <div class="card-body">

                    <?php if(Session::has('message')): ?>
                         <div class="alert alert-success" role="alert">
                            <?php echo e(Session::get('message')); ?>

                        </div>
                    <?php endif; ?>

                      <form action="<?php echo e(route('forget.password.post')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="form-group mb-3">
                              <label for="email_address" class="">E-Mail Address</label>
                              <div class="">
                                  <input type="text" id="email_address" class="form-control" name="email" required autofocus>
                                  <?php if($errors->has('email')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="mb-3">
                              <button type="submit" class="btn btn-primary form-control">
                                  Send Password Reset Link
                              </button>
                          </div>
                      </form>

                  </div>
              </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.min', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bryks\resources\views/auth/forgot.blade.php ENDPATH**/ ?>