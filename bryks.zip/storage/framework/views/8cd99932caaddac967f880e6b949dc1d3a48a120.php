<?php $__env->startSection('title', 'Manage Admin'); ?>
<?php $__env->startSection('content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <div class="container " style="padding: 12px">
        <button class="mb-3 float-right btn btn-outline-info" onclick="window.location ='<?php echo e(url('create_admin')); ?>'">Create
            new</button>
        <div class="card">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success text-center"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-responsive">
                    <thead class="thead-inverse">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Status</th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $data = DB::table('users')
                                ->orderBy('id', 'desc')
                                ->get();
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($i + 1); ?></td>
                                <td><?php echo e($data->username); ?></td>
                                <td><?php echo e($data->email); ?></td>
                                <td><?php echo e($data->phone_no); ?></td>
                                <td><a data-id="<?php echo e($data->id); ?>" data-value="<?php echo e($data->status); ?>" id="change_stat"
                                        class="btn change_stat <?php echo e($data->status == 0 ? 'btn-danger' : 'btn-success'); ?>"><?php echo e($data->status == 0 ? 'Deactive' : 'Active'); ?></a>
                                </td>
                                <td> <a href="<?php echo e(url('admin/delete_admin/' . $data->id)); ?>"
                                        class="btn btn-outline-danger">Delete</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
            
                    </div>
                </div>
            </div> --}}
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {



            $(".change_stat").click(function(e) {
                e.preventDefault();
                const id = $(this).data('id');
                const value = $(this).data('value');


                $.ajax({
                    type: "post",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "<?php echo e(url('admin/update_admin_status')); ?>",
                    data: {
                        "id": id,
                        "status": value == 1 ? 0 : 1,
                        "title": ''
                    },
                    // dataType: "dataType",
                    success: function(response) {
                        if (response.status == 401) {
                            Swal.fire({
                                icon: 'error',
                                title: response.error,
                                showConfirmButton: false,
                                timer: 1500
                            })
                            // $(".spinner-border").css("display", "none");
                            // $(".login_btn").css("display", "block");
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: response.message,
                                showConfirmButton: false,
                                timer: 1500
                            });
                            window.location.reload(true);
                        }
                    }
                });

            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bryks\resources\views/admin/administrator.blade.php ENDPATH**/ ?>