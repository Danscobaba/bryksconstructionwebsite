<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('content'); ?>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <div class="container">
        <h1 class="text-center font-extrabold text-4xl">About</h1>
        <div class="card mt-5">
            <?php
                 $data = DB::table('about')->where('id', 1)->first();
            ?>

            <form action="<?php echo e(url('admin/save_about')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <textarea name="description" class="ckeditor form-control"><?php echo e($data->description); ?></textarea>
              <input type="submit" class="btn btn-outline-success form-control" value="update">
          </form>
        </div>
    </div>
    <script>
        CKEDITOR.replace( 'ckeditor' );
      </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bryks\resources\views/admin/about.blade.php ENDPATH**/ ?>